VINYL PC HELPER (Windows 10/11)

1. Install the .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0
2. Open this folder in a terminal and run:   dotnet run
3. Play something in Spotify, Apple Music, YouTube, VLC...
4. Open the Vinyl page and press the "Connect to my PC" button (monitor icon) in the top bar.

The record will follow your music: song, artwork, play/pause and position.
The page's play/pause and skip buttons also control your music app.
Everything stays on your computer (localhost:5179). No login.

Tip: use Chrome or Edge. If the page can't connect, allow "local network access" when the browser asks.
