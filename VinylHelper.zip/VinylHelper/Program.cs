// Vinyl PC helper: shares what Windows is playing (Spotify, Apple Music, YouTube, VLC...) with the Vinyl page.
// Only listens on this computer (localhost). No login, nothing sent online.
using System.Net;
using System.Text.Json;
using Windows.Media.Control;
using Windows.Storage.Streams;

const string Prefix = "http://localhost:5179/";
var manager = await GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
byte[]? artBytes = null; string artId = ""; string lastKey = "";

var listener = new HttpListener();
listener.Prefixes.Add(Prefix);
listener.Start();
Console.WriteLine($"Vinyl helper running at {Prefix}  —  open the Vinyl page and press 'Connect to my PC'. Ctrl+C to stop.");

while (true)
{
    var ctx = await listener.GetContextAsync();
    _ = Task.Run(() => Handle(ctx));
}

async Task Handle(HttpListenerContext ctx)
{
    var res = ctx.Response;
    res.Headers["Access-Control-Allow-Origin"] = "*";
    res.Headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS";
    res.Headers["Access-Control-Allow-Headers"] = "*";
    res.Headers["Access-Control-Allow-Private-Network"] = "true";
    try
    {
        if (ctx.Request.HttpMethod == "OPTIONS") { res.StatusCode = 204; return; }
        var path = ctx.Request.Url!.AbsolutePath;
        var session = manager.GetCurrentSession();

        if (path == "/now-playing")
        {
            object? body = null;
            if (session != null)
            {
                var props = await session.TryGetMediaPropertiesAsync();
                var timeline = session.GetTimelineProperties();
                var info = session.GetPlaybackInfo();
                var key = $"{props.Title}|{props.Artist}|{props.AlbumTitle}";
                if (key != lastKey)
                {
                    lastKey = key; artBytes = null; artId = "";
                    if (props.Thumbnail != null)
                    {
                        using var stream = await props.Thumbnail.OpenReadAsync();
                        var buffer = new Windows.Storage.Streams.Buffer((uint)stream.Size);
                        await stream.ReadAsync(buffer, (uint)stream.Size, InputStreamOptions.None);
                        artBytes = new byte[buffer.Length];
                        using var reader = DataReader.FromBuffer(buffer); reader.ReadBytes(artBytes);
                        artId = Math.Abs(key.GetHashCode()).ToString();
                    }
                }
                var playing = info.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing;
                var pos = timeline.Position;
                if (playing) pos += DateTimeOffset.Now - timeline.LastUpdatedTime; // Spotify updates position rarely
                var app = session.SourceAppUserModelId ?? "";
                app = app.Contains("Spotify", StringComparison.OrdinalIgnoreCase) ? "Spotify"
                    : app.Contains("AppleMusic", StringComparison.OrdinalIgnoreCase) ? "Apple Music"
                    : app.Contains("chrome", StringComparison.OrdinalIgnoreCase) || app.Contains("msedge", StringComparison.OrdinalIgnoreCase) ? "Browser"
                    : app.Split('!', '.').FirstOrDefault() ?? "PC";
                body = new
                {
                    title = props.Title, artist = props.Artist, album = props.AlbumTitle,
                    duration = timeline.EndTime.TotalSeconds,
                    position = Math.Clamp(pos.TotalSeconds, 0, Math.Max(0, timeline.EndTime.TotalSeconds)),
                    playing, app, artId
                };
            }
            var json = JsonSerializer.SerializeToUtf8Bytes(body);
            res.ContentType = "application/json";
            await res.OutputStream.WriteAsync(json);
        }
        else if (path == "/artwork" && artBytes != null)
        {
            res.ContentType = "image/jpeg";
            await res.OutputStream.WriteAsync(artBytes);
        }
        else if (path == "/control" && session != null)
        {
            switch (ctx.Request.QueryString["action"])
            {
                case "toggle": await session.TryTogglePlayPauseAsync(); break;
                case "next": await session.TrySkipNextAsync(); break;
                case "previous": await session.TrySkipPreviousAsync(); break;
            }
            res.StatusCode = 204;
        }
        else res.StatusCode = 404;
    }
    catch (Exception e) { Console.WriteLine(e.Message); res.StatusCode = 500; }
    finally { res.Close(); }
}
